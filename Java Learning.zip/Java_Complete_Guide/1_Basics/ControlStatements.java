public class ControlStatements {
    public static void main(String[] args) {
        int num = 10;
        if (num > 5) {
            System.out.println("Number is greater than 5");
        }

        for (int i = 0; i < 5; i++) {
            System.out.println("i: " + i);
        }
    }
}